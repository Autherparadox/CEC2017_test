function [BestFitness, yy] = I_CPA(pop,dim,ub,lb,maxIter,fhd,varargin)


w_max = 0.9;        
w_min = 0.4;         
c1 = 2;             
c2 = 2;              
X = zeros(pop, dim);    
V = zeros(pop, dim);    


r = 4;  
chaotic_seq = zeros(pop, 1); 
chaotic_seq(1) = rand();   
for i = 2:pop
    chaotic_seq(i) = r * chaotic_seq(i - 1) * (1 - chaotic_seq(i - 1));
end


for i = 1:pop
    X(i, :) = lb + (ub - lb) .* chaotic_seq(i);  
    V(i, :) = rand(1, dim);                     
end


Fitness = zeros(pop, 1);
for i = 1:pop
    Fitness(i) = feval(fhd,X(i,:)',varargin{:});
end


[BestFitness, idx] = min(Fitness);
BestSolution = X(idx, :);
P_best = X;        
P_best_fitness = Fitness; 


for iter = 1:maxIter

    w = w_max - (w_max - w_min) * (iter / maxIter);
    

    for i = 1:pop

        chaotic_factor = r * chaotic_seq(i) * (1 - chaotic_seq(i));

        V(i, :) = w * V(i, :) + ...
                  c1 * rand(1, dim) .* (P_best(i, :) - X(i, :)) + ...
                  c2 * rand(1, dim) .* (BestSolution - X(i, :)) + ...
                  chaotic_factor * (ub - lb) .* (2 * rand(1, dim) - 1);

        X(i, :) = X(i, :) + V(i, :);

        X(i, :) = min(max(X(i, :), lb), ub);
    end

    for i = 1:pop
        Fitness(i) = feval(fhd,X(i,:)',varargin{:});

        if Fitness(i) < P_best_fitness(i)
            P_best(i, :) = X(i, :);
            P_best_fitness(i) = Fitness(i);
        end

        if Fitness(i) < BestFitness
            BestFitness = Fitness(i);
            BestSolution = X(i, :);
        end
    end

    chaotic_seq = r * chaotic_seq .* (1 - chaotic_seq);
    
    yy(iter)=BestFitness;

end
end