function [fPbest,yy]=BES(pop,dim,ub,lb,maxIter,fhd,varargin)
aerfa=1.8;%1.5~2
a=8;%5~10
R=1.3;%0.5~2
c1=1.5;%1~2
c2=1.5;%1`2
P=initialization(pop,ub,lb,dim);
fP=zeros(1,pop);
for t=1:maxIter
    for i=1:pop
        fP(i)=feval(fhd,P(i,:)',varargin{:});
        [~,index]=min(fP);
        Pbest=P(index,:);
        Pmean=mean(P,1);
        Pnew(i,:)=Pbest+aerfa*rand*(Pmean-P(i,:));
        fPnew(i)=feval(fhd,Pnew(i,:)',varargin{:});
        fPbest=feval(fhd,Pbest',varargin{:});
        if fPnew(i)<fP(i)
            P(i,:)=Pnew(i,:);
        else if fPnew(i)<fPbest
                Pbest=Pnew(i,:);
        end
        end
    end
    for i=1:(pop-1)
        fP(i)=feval(fhd,P(i,:)',varargin{:});
        [~,index]=min(fP);
        Pbest=P(index,:);
        Pmean=mean(P,1);
        theta(i)=a*pi*rand;
        r(i)=theta(i)+R*rand;
        xr(i)=r(i)*sin(theta(i));
        yr(i)=r(i)*cos(theta(i));
        x(i)=xr(i)/max(abs(xr));
        y(i)=yr(i)/max(abs(yr));
        Pnew(i,:)=P(i,:)+y(i)*(P(i,:)-P(i+1,:))+x(i)*(P(i,:)-Pmean);
        fPnew(i)=feval(fhd,Pnew(i,:)',varargin{:});
        fPbest=feval(fhd,Pbest',varargin{:});
        if fPnew(i)<fP(i)
            P(i,:)=Pnew(i,:);
        else if fPnew(i)<fPbest
                Pbest=Pnew(i,:);
        end
        end
    end
    for i=1:pop
        fP(i)=feval(fhd,P(i,:)',varargin{:});
        [~,index]=min(fP);
        Pbest=P(index,:);
        Pmean=mean(P,1);
        theta(i)=a*pi*rand;
        r(i)=theta(i);
        xr(i)=r(i)*sinh(theta(i));
        yr(i)=r(i)*cosh(theta(i));
        x1(i)=xr(i)/max(abs(xr));
        y1(i)=yr(i)/max(abs(yr));
        Pnew(i,:)=rand*Pbest+x1(i)*(P(i,:)-c1*Pmean)+y1(i)*(P(i,:)-c2*Pbest);
        fPnew(i)=feval(fhd,Pnew(i,:)',varargin{:});
        fPbest=feval(fhd,Pbest',varargin{:});
        if fPnew(i)<fP(i)
            P(i,:)=Pnew(i,:);
        else if fPnew(i)<fPbest
                Pbest=Pnew(i,:);
        end
        end
    end
    fPbest=feval(fhd,Pbest',varargin{:});
    Best_Pos=Pbest;
    Best_fitness=fPbest;
    yy(t)=fPbest;
end
end