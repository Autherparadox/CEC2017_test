function [Best_fitness, yy]=PSO(pop,dim,ub,lb,maxIter,fhd,varargin)
c1=1.4;
c2=1.4;
w=0.9;
vmax=0.5*ub;
vmin=0.5*lb;
X=initialization(pop,ub,lb,dim);
V=initialization(pop,vmax,vmin,dim);
fitness=zeros(1,pop);
for i=1:pop
    fitness(i)=feval(fhd,X(i,:)',varargin{:});
end
pBest=X;
pBestFitness=fitness;
[~,index]=min(fitness);
gBestFitness=fitness(index);
gBest=X(index,:);
for t=1:maxIter
    for i=1:pop
        fitness(i)=feval(fhd,X(i,:)',varargin{:});
        if fitness(i)<pBestFitness(i)
            pBest(i,:)=X(i,:);
            pBestFitness(i)=fitness(i);
        end
        if fitness(i)<gBestFitness
            gBestFitness=fitness(i);
            gBest=X(i,:);
        end
        V(i,:)=w*V(i,:)+c1*rand*(pBest(i,:)-X(i,:))+c2*rand*(gBest-X(i,:));
        X(i,:)=X(i,:)+V(i,:);
        X(i,:)=BoundaryCheck(X(i,:),ub,lb,dim);
    end
    Best_Pos=gBest;
    Best_fitness=gBestFitness;
    yy(t)=Best_fitness;
end
end