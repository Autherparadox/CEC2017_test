function [Global_Best_Score, yy]=FA(pop,dim,ub,lb,MaxIter,fhd,varargin)
  beta0=2;
  gamma=1;
  alpha=0.2;
  dmax=norm(ub-lb);
  x=initialization(pop,ub,lb,dim);
  Fitness=zeros(1,pop);
  for i=1:pop
      Fitness(i)=feval(fhd,x(i,:)',varargin{:});
  end
  [~,Index]=min(Fitness);
  Global_Best_Pos=x(Index,:);
  Global_Best_Score=Fitness(Index);
  x_new=x;
  for t=1:MaxIter
      for i=1:pop
          for j=1:dim
              if Fitness(j)<Fitness(i)
                  r_ij=norm(x(i,:)-x(j,:))./dmax;
                  beta=beta0*exp(-gamma*r_ij^2);
                  Pos_new=x(i,:)+beta*(x(j,:)-x(i,:))+alpha.*rand(1,dim);
                  Pos_new=BoundrayCheck(Pos_new,ub,lb,dim);
                  Fitness_new=feval(fhd,Pos_new',varargin{:});
                  if Fitness_new<Fitness(i)
                      x_new(i,:)=Pos_new;
                      Fitness(i)=Fitness_new;
                      if Fitness_new<Global_Best_Score
                          Global_Best_Score=Fitness_new;
                          Global_Best_Pos=Pos_new;
                      end
                  end
              end
          end
      end
      x_double=[x;x_new];
      for i=1:2*pop
          Fitness_double(i)=feval(fhd,x_double(i,:)',varargin{:});
      end
      [~,SortIndex]=sort(Fitness_double);
      for k=1:pop 
          x(k,:)=x_double(SortIndex(k),:);
      end
      yy(t)=Global_Best_Score;
  end
  Best_Pos=Global_Best_Pos;
  Best_Score=Global_Best_Score;
end