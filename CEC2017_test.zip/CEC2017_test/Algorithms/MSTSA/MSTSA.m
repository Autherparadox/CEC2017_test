function [BestFitness, yy] = MSTSA(pop,dim,ub,lb,maxIter,fhd,varargin)


S_max = 3;          
epsilon = 0.01;     
eX = zeros(pop, dim);  
X=initialization(pop,ub,lb,dim);


Fitness = zeros(pop, 1);
for i = 1:pop
    Fitness(i) = feval(fhd,X(i,:)',varargin{:});
end


[BestFitness, idx] = min(Fitness);
BestSolution = X(idx, :);


for iter = 1:maxIter

    Seeds = [];  
    for i = 1:pop

        S_i = ceil(S_max * (BestFitness - Fitness(i)) / (BestFitness - max(Fitness) + epsilon));
        for s = 1:S_i

            Seed = X(i, :) + epsilon * (ub - lb) .* (2 * rand(1, dim) - 1);

            Seed = min(max(Seed, lb), ub);
            Seeds = [Seeds; Seed];
        end
    end
    

    SeedFitness = zeros(size(Seeds, 1), 1);
    for j = 1:size(Seeds, 1)
        SeedFitness(j) = feval(fhd,Seeds(j, :)',varargin{:});
    end
    

    CombinedX = [X; Seeds];
    CombinedFitness = [Fitness; SeedFitness];
    

    [~, sortedIdx] = sort(CombinedFitness);
    X = CombinedX(sortedIdx(1:pop), :);
    Fitness = CombinedFitness(sortedIdx(1:pop));
    

    [currentBestFitness, idx] = min(Fitness);
    if currentBestFitness < BestFitness
        BestFitness = currentBestFitness;
        BestSolution = X(idx, :);
    end
    yy(iter)=BestFitness;

end
end