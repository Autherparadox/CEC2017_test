clc;
clear all;
close all;
% 示例数据
group1 = [2.1, 3.4, 2.8, 4.1, 3.7];
group2 = [3.2, 4.3, 4.1, 5.0, 3.9];

% Wilcoxon 秩和检验 (Mann-Whitney U 检验)
[p, h, stats] = ranksum(group1, group2);

% 输出结果
fprintf('p 值: %.4f\n', p);
fprintf('检验结果 (h): %d\n', h);
fprintf('检验统计量 (ranksum): %.4f\n', stats.ranksum);