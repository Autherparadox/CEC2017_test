clc
clear
close all
addpath(genpath(pwd))
fhd=str2func('cec17_func');
dim=30;
for i=1:dim
    ub(i)=100;
    lb(i)=-100;
end
maxIter=500; 
pop=30; 
%% Test functions：F3, F8, F9, F14, F15, F18, F19, F27, F30
func_num=19;    
%% plot
[~,BestforI_BES]=I_BES(pop,dim,ub,lb,maxIter,fhd,func_num);
[~,BestforBES]=BES(pop,dim,ub,lb,maxIter,fhd,func_num);
[~,BestforPSO]=PSO(pop,dim,ub,lb,maxIter,fhd,func_num);
[~,BestforFA]=FA(pop,dim,ub,lb,maxIter,fhd,func_num);
[~,BestforMSTSA]=MSTSA(pop,dim,ub,lb,maxIter,fhd,func_num);
[~,BestforI_CPA]=I_CPA(pop,dim,ub,lb,maxIter,fhd,func_num);

t=1:1:maxIter;
semilogy(t,BestforI_BES,'y-*','Color',[1 0.07843 0.57647]','linewidth',1,'MarkerIndices',1:15:maxIter)
hold on
semilogy(t,BestforBES,'b-.','linewidth',1,'MarkerIndices',1:15:maxIter)
hold on
semilogy(t,BestforPSO,'k--','linewidth',1)
hold on
semilogy(t,BestforFA,'c','linewidth',1)
hold on
semilogy(t,BestforMSTSA,'g-^','linewidth',1,'MarkerIndices',1:15:maxIter)
hold on
semilogy(t,BestforI_CPA,'d--','Color',[1 0.5 0]','linewidth',1,'MarkerIndices',1:15:maxIter)
hold on

legend('I-BES','BES','PSO','FA','MSTSA','I-CPA')
Fun_name=['F' num2str(func_num)]; 
title( Fun_name);
xlabel('Iteration number');
ylabel('Function value');
%% data save
%%  I_BES
% for i=1:30
%     [~,BestforI_BES]=I_BES(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_I_BES(i)=BestforI_BES(1,500);
% end
% Best_I_BES=min(data_I_BES)
% Mean_I_BES=mean(data_I_BES)
% std_I_BES=std(data_I_BES)
%% BES
% for i=1:30
%     [~,BestforBES]=BES(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_BES(i)=BestforBES(1,500);
% end
% Best_BES=min(data_BES)
% Mean_BES=mean(data_BES)
% std_BES=std(data_BES)
%% PSO
% for i=1:30
%     [~,BestforPSO]=PSO(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_PSO(i)=BestforPSO(1,500);
% end
% Best_PSO=min(data_PSO)
% Mean_PSO=mean(data_PSO)
% std_PSO=std(data_PSO)
%% FA
% for i=1:30
%     [~,BestforFA]=FA(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_FA(i)=BestforFA(1,500);
% end
% Best_FA=min(data_FA)
% Mean_FA=mean(data_FA)
% std_FA=std(data_FA)
%% MSTSA
% for i=1:30
%     [~,BestforMSTSA]=MSTSA(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_MSTSA(i)=BestforMSTSA(1,500);
% end
% Best_MSTSA=min(data_MSTSA)
% Mean_MSTSA=mean(data_MSTSA)
% std_MSTSA=std(data_MSTSA)
%% I-CPA
% for i=1:30
%     [~,BestforI_CPA]=I_CPA(pop,dim,ub,lb,maxIter,fhd,func_num);
%     data_I_CPA(i)=BestforI_CPA(1,500);
% end
% Best_I_CPA=min(data_I_CPA)
% Mean_I_CPA=mean(data_I_CPA)
% std_I_CPA=std(data_I_CPA)
%% wilcoxon rank-sum test results
% [p1, h1, stats1] = ranksum(data_I_BES, data_BES);
% [p2, h2, stats2] = ranksum(data_I_BES, data_PSO);
% [p3, h3, stats3] = ranksum(data_I_BES, data_FA);
% [p4, h4, stats4] = ranksum(data_I_BES, data_MSTSA);
% [p5, h5, stats5] = ranksum(data_I_BES, data_I_CPA);
% 
% fprintf('BES p value: %.4f\n', p1);
% fprintf('PSO p value: %.4f\n', p2);
% fprintf('FA p value: %.4f\n', p3);
% fprintf('MSTSA p value: %.4f\n', p4);
% fprintf('I-CPA p value: %.4f\n', p5);




